Usage: 
chmod 744 checker_linux
./checker_linux [input_file_name] [output_file_name]


Ex: ./checker_linux case1.dat result1.dat

Results:
[Check] Cut size = 3400 matched!
[Check] Balance passed:: 60300(min) < 76453(G1), 74297(G2) < 90450(max)
=================================
Congratulations! Legal Solution!!
=================================

